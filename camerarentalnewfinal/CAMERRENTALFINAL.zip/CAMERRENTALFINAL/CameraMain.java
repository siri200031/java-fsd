package camerarentalnewfinal;

public class CameraMain {
	
		public static void main(String[] args) {
			CameraRentalAppl Appl = new CameraRentalAppl();
			Appl.start();
		}
	}

