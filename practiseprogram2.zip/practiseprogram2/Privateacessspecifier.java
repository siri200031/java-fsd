package practiseprogram2;

public class Privateacessspecifier {
	private void display() 
	{ 
		System.out.println("You are using private access specifier"); 
	} 




	public static void main(String[] args) {
		//private
		System.out.println("we are using Private Access Specifier");
		Privateacessspecifier  obj = new Privateacessspecifier(); 
		//trying to access private method of another class 
		//obj.display();

	}
}

