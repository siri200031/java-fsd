package practiseprogram2;

public class Acessmodifier {

}
