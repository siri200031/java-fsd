package emailvalidation;


	import java.util.Scanner;

	public class emailvalidation {
		static boolean isValid(String email) {
			String matchingkeywords="^[\\w-\\.+]*[\\w-\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
			return email.matches(matchingkeywords);
		}
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			String email;
			int i;
			for(i=0;i<=3;i++) {
				System.out.println("Give me you Email address ");
				email=sc.next();
				
				System.out.println("Your email "+email);
				System.out.println();
				System.out.println("Is it valid! "+isValid(email));
				System.out.println();
			}
		}
	}

