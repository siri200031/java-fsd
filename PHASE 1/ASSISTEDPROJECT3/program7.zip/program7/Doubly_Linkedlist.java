package program7;


	class Node {
	    int data;
	    Node prev;
	    Node next;

	    public Node(int data) {
	        this.data = data;
	        this.prev = null;
	        this.next = null;
	    }
	}

	class DoublyLinkedList {
	    Node head;

	    public void append(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	            newNode.prev = current;
	        }
	    }

	    public void traverseForward() {
	        Node current = head;
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	    public void traverseBackward() {
	        Node current = head;
	        while (current.next != null) {
	            current = current.next;
	        }

	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.prev;
	        }
	        System.out.println();
	    }
	}

	public class Doubly_Linkedlist {
	    public static void main(String[] args) {
	        DoublyLinkedList list = new DoublyLinkedList();
	        list.append(1);
	        list.append(2);
	        list.append(3);
	        list.append(4);
	        
	        System.out.println("Forward traversal:");
	        list.traverseForward();

	        System.out.println("Backward traversal:");
	        list.traverseBackward();
	    }
	}

