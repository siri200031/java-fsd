package practiseprogram4;

public class Constructortype1 {
	int id;
	String name;

	void display() {
		System.out.println(id+" "+name);
	}



	public static void main(String[] args) {

		Constructortype1 emp1=new Constructortype1();
		Constructortype1 emp2=new Constructortype1();

		emp1.display();
		emp2.display();
	}
}
