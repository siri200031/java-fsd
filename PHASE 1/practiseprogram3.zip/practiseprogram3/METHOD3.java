package practiseprogram3;

public class METHOD3 {
	public void area(int b,int h)
	{
		System.out.println("Area of Triangle : "+(0.5*b*h));
	}
	public void area(int r) 
	{
		System.out.println("Area of Circle : "+(3.14*r*r));
	}

	public static void main(String args[])
	{

		METHOD3 METHOD3 = new METHOD3();
		METHOD3.area(10,12);
		METHOD3.area(5);  
	}
}
