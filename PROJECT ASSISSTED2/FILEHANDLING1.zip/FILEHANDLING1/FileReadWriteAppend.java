package FILEHANDLING1;


import java.io.*;

public class FileReadWriteAppend {
	public static void main(String[] args) {

		String filePath = "sample.txt";


		writeToFile(filePath, "This is some text that will be written to the file.");


		String content = readFromFile(filePath);
		System.out.println("Content read from the file:\n" + content);


		appendToFile(filePath, "\nThis text will be appended to the file.");


		content = readFromFile(filePath);
		System.out.println("\nUpdated content after appending:\n" + content);
	}


	public static void writeToFile(String filePath, String content) {
		try (FileWriter fileWriter = new FileWriter(filePath)) {
			fileWriter.write(content);
			System.out.println("Content written to the file.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public static String readFromFile(String filePath) {
		StringBuilder content = new StringBuilder();
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath)) ) {
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				content.append(line).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return content.toString();
	}


	public static void appendToFile(String filePath, String content) {
		try (FileWriter fileWriter = new FileWriter(filePath, true)) {
			fileWriter.write(content);
			System.out.println("Content appended to the file.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

