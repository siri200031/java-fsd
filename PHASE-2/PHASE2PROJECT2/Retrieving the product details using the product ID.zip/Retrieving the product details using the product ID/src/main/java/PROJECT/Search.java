package PROJECT; 
import java.io.IOException; 
import java.io.PrintWriter; 
import java.sql.*; 
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
/** 
* Servlet implementation class Search 
*/ 
@WebServlet("/Search") 
public class Search extends HttpServlet { 
private static final long serialVersionUID = 1L; 
/** 
* @see HttpServlet#HttpServlet() 
*/ 
public Search() { 
super(); 
// TODO Auto-generated constructor stub 
} 
/** 
* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response) 
*/ 
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
// TODO Auto-generated method stub 
response.getWriter().append("Served at: ").append(request.getContextPath()); 
} 
/** 
* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response) 
*/ 
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { 
resp.setContentType("text/html"); 
PrintWriter out=resp.getWriter(); 
int mypid=Integer.parseInt(req.getParameter("pid")); 
try { 
Class.forName("com.mysql.cj.jdbc.Driver"); 
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mphasis_db","root","suvashree#1234"); 
PreparedStatement ps=con.prepareStatement("select *from product where pid=?"); 
ps.setInt(1, mypid); 
out.print("<table width=75% border=1>"); 
out.print("<caption>Product result:</caption>"); 
ResultSet rs=ps.executeQuery(); 
ResultSetMetaData rsmd=rs.getMetaData(); 
int totalcolumn=rsmd.getColumnCount(); 
out.print("<tr>"); 
for(int i=1;i<=totalcolumn;i++) { 
out.print("<th>"+rsmd.getColumnName(i)+"</th>"); 
} 
out.print("<tr>"); 
while(rs.next()) { 
out.print("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"); 
} 
out.print("</table"); 
} 
catch(Exception ex) { 
out.print(ex); 
}} 
} 
