/**
 * 
 */
/**
 * 
 */
module JDBCSetup2 {
	requires java.sql;
}